package softuni.exam.models.enums;

public enum Type {
    SUV, coupe, sport
}
