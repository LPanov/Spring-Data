package softuni.exam.repository;

// TODO:
public interface CarRepository {

}
