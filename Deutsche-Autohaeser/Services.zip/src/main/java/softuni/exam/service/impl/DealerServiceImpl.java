package softuni.exam.service.impl;

import jakarta.xml.bind.JAXBException;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.repository.DealerRepository;
import softuni.exam.service.DealerService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class DealerServiceImpl implements DealerService {

    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final XmlParser xmlParser;
    private final DealerRepository dealerRepository;

    public DealerServiceImpl(ModelMapper modelMapper, ValidationUtil validationUtil, XmlParser xmlParser, DealerRepository dealerRepository) {
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.xmlParser = xmlParser;
        this.dealerRepository = dealerRepository;
    }

    @Override
    public boolean areImported() {
        return dealerRepository.count() > 0;
    }

    @Override
    public String readDealersFromFile() throws IOException {
        Path path = Path.of("src/main/resources/files/xml/dealers.xml");
        return Files.readString(path);
    }

    @Override
    public String importDealers() throws IOException, JAXBException {
        return "";
    }
}
