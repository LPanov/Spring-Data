insert into dealerships (id, name, description)
values    (1, 'Autohaus Sternblick', 'Fahrfreude trifft deutsche Praezision Ihr Autohaus des Vertrauens'),
          (2, 'Koenig Motoren', 'Koeniglicher Service fuer Ihre Mobilitaet'),
          (3, 'Autotechnik Bergmann', 'Tradition trifft Innovation Ihr Partner fuer Qualitaet'),
          (4, 'Meisterwagen Lichtenfeld', 'Exklusive Fahrzeuge Persoenliche Beratung Faire Preise'),
          (5, 'Fahrzeugwelt Neumann', 'Entdecken Sie unsere Welt der Automobile'),
          (6, 'Autozentrum Falkenstein', 'Stark wie ein Falke Ihr Auto in besten Haenden'),
          (7, 'Schneider Mobil', 'Mobilitaet mit Stil Schneider machts moeglich'),
          (8, 'Autohaus Edelkraft', 'Starke Autos Starker Service'),
          (9, 'Motorpark Lindenhof', 'Ihr Ziel fuer TopGebrauchtwagen und Werkstattqualitaet'),
          (10, 'RheinMobil', 'Ihre Mobilitaet beginnt hier direkt am Rhein'),
          (11, 'Gruber Fahrzeughandel', 'Verlaesslichkeit die bewegt'),
          (12, 'Autohaus Silberstein', 'Wir bringen Glanz in Ihre Garage'),
          (13, 'Berg & Sohn Automobile', 'Familiengefuehrt Kundenorientiert Fahrzeugbegeistert'),
          (14, 'Nordstern Auto GmbH', 'Wo Ihre Fahrt beginnt mit Qualitaet aus dem Norden'),
          (15, 'Kraftmobil Thueringen', 'Zuverlaessige Mobilitaet aus dem Herzen Deutschlands'),
          (16, 'Vogel & Partner Cars', 'Ihr Autoexperte persoenlich ehrlich kompetent'),
          (17, 'Autohandel Kaiserblick', 'Kaiserlicher Service zu fairen Preisen'),
          (18, 'Werkstatt Adlerhorst', 'Schnell Stark Sicher wie ein Adler im Flug'),
          (19, 'Stadtmobil Breuninger', 'Fahrzeuge fuer Stadtmenschen mit Anspruch');


