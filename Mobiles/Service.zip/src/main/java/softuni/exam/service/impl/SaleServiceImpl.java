package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.repository.SaleRepository;
import softuni.exam.service.SaleService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class SaleServiceImpl implements SaleService {

    private final ModelMapper modelMapper;
    private final ValidationUtil validator;
    private final Gson gson;
    private final SaleRepository saleRepository;

    public SaleServiceImpl(ModelMapper modelMapper, ValidationUtil validationUtil, Gson gson, SaleRepository saleRepository) {
        this.modelMapper = modelMapper;
        this.validator = validationUtil;
        this.gson = gson;
        this.saleRepository = saleRepository;
    }

    @Override
    public boolean areImported() {
        return saleRepository.count() > 0;
    }

    @Override
    public String readSalesFileContent() throws IOException {
        Path path = Path.of("src/main/resources/files/json/sales.json");
        return Files.readString(path);
    }

    @Override
    public String importSales() throws IOException {
        return "";
    }
}
